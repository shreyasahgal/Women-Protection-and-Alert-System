# women-security-system

Design and implement a robust, real-time online women's security system that ensures quick response and support in emergency situations.

OS – Windows 7 or above
IDE– NetBeans IDE 8.2
FRONT END – JSP, CSS
BACK END – MySQL 8.0
BROWSER – IE 11.0
SERVER – Apache Tomcat 8.0.27.0
SCRIPTING LANGUAGE – JavaScript
